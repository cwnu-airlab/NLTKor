
import warnings

# backwards compatibility
from .wsd_reader import *

warnings.warn('Module macmorphoreader is deprecated. Use module pos_reader instead.')
