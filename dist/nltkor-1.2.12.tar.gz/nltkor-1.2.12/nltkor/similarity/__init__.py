# The following trick allows us to import the classes directly from the similarity module:
from .cosine_similarity import CosineSimilarity
from .classical import LCSubstringSimilarity, LCSubsequenceSimilarity, JaroSimilarity