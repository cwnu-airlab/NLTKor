
from .train_srl import *
from .srl_reader import SRLReader
