from nltkor.sejong.sejong_download import SejongDir

__all__=['ssem']
